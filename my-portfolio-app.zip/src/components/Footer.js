function Footer() {
  return (
    <footer>
      <p>Made by Mohamed © 2026</p>
    </footer>
  );
}

export default Footer;