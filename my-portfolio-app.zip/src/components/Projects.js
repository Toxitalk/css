function Projects() {
  return (
    <section className="projects" id="projects">
      <h2>Featured Projects</h2>

      <div className="project-grid">

        <div className="card">
          <img
            src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3"
            alt=""
          />
          <h3>React Space</h3>
          <p>Handy tool built with React.</p>
        </div>

        <div className="card">
          <img
            src="https://images.unsplash.com/photo-1460317442991-0ec209397118"
            alt=""
          />
          <h3>React Infinite Scroll</h3>
          <p>Infinite scroll application.</p>
        </div>

        <div className="card">
          <img
            src="https://images.unsplash.com/photo-1446776811953-b23d57bd21aa"
            alt=""
          />
          <h3>Photo Gallery</h3>
          <p>Responsive gallery app.</p>
        </div>

        <div className="card">
          <img
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085"
            alt=""
          />
          <h3>Event Planner</h3>
          <p>Organize your events easily.</p>
        </div>

      </div>
    </section>
  );
}

export default Projects;