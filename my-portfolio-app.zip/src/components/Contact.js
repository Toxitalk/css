function Contact() {
  return (
    <section className="contact" id="contact">
      <h2>Contact me</h2>

      <form>
        <input type="text" placeholder="Name" />
        <input type="email" placeholder="Email Address" />
        <input type="text" placeholder="Type of enquiry" />

        <textarea
          placeholder="Your message"
          rows="6"
        ></textarea>

        <button type="submit">Submit</button>
      </form>
    </section>
  );
}

export default Contact;