function Header() {
  return (
    <header className="header">
      <div className="logo">Portfolio</div>

      <nav>
        <a href="#home">Home</a>
        <a href="#projects">Projects</a>
        <a href="#contact">Contact</a>
      </nav>

      <div className="socials">
        <a href="https://github.com">GitHub</a>
        <a href="https://linkedin.com">LinkedIn</a>
      </div>
    </header>
  );
}

export default Header;