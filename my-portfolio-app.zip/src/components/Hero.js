function Hero() {
  return (
    <section className="hero" id="home">
      <img
        src="https://i.pravatar.cc/200"
        alt="avatar"
      />

      <h1>A frontend developer specialised in React</h1>
    </section>
  );
}

export default Hero;